def removeDashes(uuid):
    return uuid